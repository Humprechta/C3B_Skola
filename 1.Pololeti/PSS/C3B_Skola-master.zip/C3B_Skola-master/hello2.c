#include<stdio.h>
int main(){
printf("hello world");
scitani(5,5);
return 0;
}
