#include<stdio.h>
int main(){
printf("hello world");
int x = 8;
int y = 61;
int z = x + y;
printf("%d",z);
printf("\n");
return 0;
}
