#include<stdio.h>
int scitani(int a, int b){
int c = a + b;
printf("%d",c);
printf("/n");
}
